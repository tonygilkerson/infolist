from .infolistcli import InfolistCLI

def main():
    InfolistCLI().cmdloop()

if __name__ == '__main__':
    main()